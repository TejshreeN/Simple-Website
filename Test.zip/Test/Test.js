 import {useState} from "react"

export default function Student_Form_101()
{
    
  const [birthdate, setBirthdate] = useState('');
  const [prn, setPRN] = useState('');
  const [aadhar, setAadhar] = useState('');
  const [submitClicked, setSubmitClicked] = useState(false);
  const [errors, setErrors] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitClicked(true);
    setErrors([]);

    const errorList = [];

    // Validation rule 1: Age should be between 21 and 25
    const today = new Date();
    const birthdateYear = parseInt(birthdate.substr(0, 4));
    const age = today.getFullYear() - birthdateYear;
    if (age < 21 || age > 25) {
      errorList.push('Age should be between 21 and 25 years.');
    }

    // Validation rule 2: PRN should be 12 digits long
    if (prn.length !== 12) {
      errorList.push('PRN should be exactly 12 digits long.');
    }

    // Validation rule 3: Aadhar number format
    const aadharRegex = /^[0-9]{4} [0-9]{4} [0-9]{4}$/;
    if (!aadharRegex.test(aadhar)) {
      errorList.push(
        'Aadhar number should be in the format: xxxx xxxx xxxx (one space between groups of 4 digits).'
      );
    }

    setErrors(errorList);

    if (errorList.length === 0) {
      // Form submitted successfully
      alert('Data submitted successfully');
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Birthdate:</label>
          <input
            type="date"
            value={birthdate}
            onChange={(e) => setBirthdate(e.target.value)}
          />
        </div>
        <div>
          <label>PRN:</label>
          <input
            type="text"
            value={prn}
            onChange={(e) => setPRN(e.target.value)}
          />
        </div>
        <div>
          <label>Aadhar number:</label>
          <input
            type="text"
            value={aadhar}
            onChange={(e) => setAadhar(e.target.value)}
          />
        </div>
        <button type="submit">Submit</button>
      </form>
      {submitClicked && errors.length > 0 && (
        <div>
          <h3>Error List:</h3>
          <ul>
            {errors.map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};





 